

export default function Daily(Props) {
    return (
        <div>
            This is the Daily Tab
        </div>
    )
}