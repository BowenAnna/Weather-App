import React from 'react';

export default function Home (props){
    console.log('This is Home - props', props);
return(
    <div>This is the Home Tab</div>
)
}