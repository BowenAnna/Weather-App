export default function Tenday () {
    return(
        <div>
        This is the Tenday Tab
    </div>
    )
}